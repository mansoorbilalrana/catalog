from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine


Base = declarative_base()
# User Table Definition
class User(Base):
	__tablename__ = 'user'	
	id = Column(Integer, primary_key = True)
	name = Column(String(80), nullable=False)
	email = Column(String(250), nullable=False)
	profile_img = Column(String(250))


# Categories Table Definition
class ItemCategories(Base):
	__tablename__ = 'itemcategories'
	id = Column(Integer, primary_key=True)
	name = Column(String(80), nullable=False)
	user_id = Column(Integer, ForeignKey('user.id'))
	user = relationship(User)
	@property
	def serialize(self):
		return {
		           'name'         : self.name,
		           'id'         : self.id,
		       }




#Items Table Definition
class ItemsLists(Base):
	__tablename__ = 'itemslists'
	id = Column(Integer, primary_key=True)
	name = Column(String(80), nullable=False)
	category_name = Column(String(80),ForeignKey('itemcategories.name'), nullable=False)
	description = Column(String(500), nullable=False)
	user_id = Column(Integer, ForeignKey('user.id'))
	user = relationship(User)
	itemCategories = relationship(ItemCategories)
	@property
	def serialize(self):
		return {
			'name': self.name,
			'id': self.id,
			'description': self.description,
			'category_name': self.category_name,
		}


#Connection To Database
engine = create_engine('sqlite:///restaurantmenu.db')
Base.metadata.create_all(engine)
