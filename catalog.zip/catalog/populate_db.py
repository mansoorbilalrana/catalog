#!/usr/bin/python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
 
from database import ItemCategories, Base, ItemsLists
 
engine = create_engine('sqlite:///restaurantmenu.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine
 
DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. Any change made against the objects in the
# session won't be persisted into the database until you call
# session.commit(). If you're not happy about the changes, you can
# revert all of them back to the last commit by calling
# session.rollback()
session = DBSession()


catalog1 = ItemCategories(name = "Soccer")
session.add(catalog1)
session.commit()

item1 = ItemsLists(name="Dummy1", description="This is First item", category_name = "Soccer", user_id = 1)
session.add(item1)
session.commit()
item2 = ItemsLists(name="Dummy2", description="This is Second item", category_name = "Soccer", user_id = 1)
session.add(item2)
session.commit()
item3 = ItemsLists(name="Dummy3", description="This is Third item", category_name = "Soccer", user_id = 1)
session.add(item3)
session.commit()


catalog2 = ItemCategories(name = "Football")
session.add(catalog2)
session.commit()

item1 = ItemsLists(name="Dummy1", description="This is First item", category_name = "Football", user_id = 1)
session.add(item1)
session.commit()
item2 = ItemsLists(name="Dummy2", description="This is Second item", category_name = "Football", user_id = 1)
session.add(item2)
session.commit()
item3 = ItemsLists(name="Dummy3", description="This is Third item", category_name = "Football", user_id = 1)
session.add(item3)
session.commit()




catalog3 = ItemCategories(name = "Cricket")
session.add(catalog3)
session.commit()

item1 = ItemsLists(name="Dummy1", description="This is First item", category_name = "Cricket", user_id = 1)
session.add(item1)
session.commit()
item2 = ItemsLists(name="Dummy2", description="This is Second item", category_name = "Cricket", user_id = 1)
session.add(item2)
session.commit()
item3 = ItemsLists(name="Dummy3", description="This is Third item", category_name = "Cricket", user_id = 1)
session.add(item3)
session.commit()


print "added items!"