## Item Catalog Project

**Overview**

Items catalog project in which users can add,edit,delete any catalog item. 
Users has to sign in with google plus account to add or modify the items.
Users can only modify their own data.

**Requisite**

This Web application Requires Python 3.7.0 [download python from python.org.](https://www.python.org/downloads/) download the version according to your operating system.

Project contains following Directories

* **static** ( All static resources like images,js and css files are placed in this folder )

* **templates** ( All html files are placed in this folder)

**Software's** Need For Running This Project

**Git**

Git is a Version Control System

You can Download Git From this link [ git-scm.com.](http://git-scm.com/downloads). Download Git According to your operating system

**Virtual Box**

Virtual Box is used to run the virtual machine [ virtualbox.org](https://www.virtualbox.org/wiki/Downloads). Install The package according to your operating system.

**Vagrant**

Vagrant is used to configure virtual machine to share files  between our computer and VM.  [You can download it from vagrantup.com.](https://www.vagrantup.com/downloads)

* Note after installing these softwares clone this REPO using gitbash or Terminal

**git clone https://github.com/udacity/fullstack-nanodegree-vm.git**

This clone give you a directory named fullstack-nanodegree-vm.

After coloning fullstack-nanodegree-vm download item catalog project and move folder into the fullstack-nanodegree-vm folder 

##Start virtual machine

Using the ternminal moved to fullstack-nanodegree-vm directory and run command **vagrant up**. This command will start VM.

##Connect to Virtual machine

When **vagrant up**. run successfully then execute command **vagrant ssh**. this command will log into  your virtual machine

Change the directory to **/vagrant** directory by typing **cd /vagrant**. This will take you to the shared folder between your virtual machine and host machine.

Run **ls**. command to see all shared files and folders. Run **cd catalog**. this command will move you to the item catalog project.

##Google Sigin

For add,edit delete items you have to create Google Api Credentials 
* Go to your app's page in the Google APIs Console � 

[console.developers.google.com/apis](https://console.developers.google.com/apis)

* Choose Credentials from the menu on the left.

* Open **Create Credential** Dropdown menu Click OAuth Client ID a new window opens select web application and press Create.

* When you're presented with a list of application types, choose **Web application**

* You can then set the name of webapplication, add **http://localhost:5000/login**,
**http://localhost:5000/gconnect** separately in Authorized JavaScript origins

* Add **http://localhost:5000** in Authorized redirect URIs then press Create it will generate the require keys.

* Downlod JSON file by pressing **DOWNLOAD JSON** button and rename the file to **client_secrets.json** and place this file in **catalog** directory

* Now open the **templates/login.html** and update the google signin button **data-clientid** to your client id.

You will then be able login to the app using google sign in.

## Run Project   
Now Run **python database.py**. This Command will Create Database Tables

Run **python populate_db.py**. this will populate database with some data.

Run **python application.py**. This will run the web server Visit http://localhost:5000 this will open item catalog project. 